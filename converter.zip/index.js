
// 'use strict';
// const path = require('path');
// const fs = require('fs').promises;
// const libre = require('libreoffice-convert');
// libre.convertAsync = require('util').promisify(libre.convert);

// async function main ()
// {
//     const ext = '.pdf';
//     const inputPath = path.join(__dirname, './input.docx');
//     const outputPath = path.join(__dirname, `./example${ext}`);
//     const docxBuf = await fs.readFile(inputPath);
//     let pdfBuf = await libre.convertAsync(docxBuf, ext, undefined);
//     await fs.writeFile(outputPath, pdfBuf);
// }

// main().catch(function (err)
// {
//     console.log(`Error converting file: ${err}`);
// });




'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const multer = require('multer');
const libre = require('libreoffice-convert');
libre.convertAsync = require('util').promisify(libre.convert);

const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.static('public'));
app.post('/upload', upload.single('docxFile'), async (req, res) =>
{
    const ext = '.pdf';
    const inputPath = req.file.path;
    const outputPath = path.join(__dirname, `./uploads/${req.file.originalname.replace('.docx', ext)}`);

    try {
        const docxBuf = await fs.readFile(inputPath);
        const pdfBuf = await libre.convertAsync(docxBuf, ext, undefined);
        await fs.writeFile(outputPath, pdfBuf);
        res.download(outputPath, (err) =>
        {
            if (err) {
                console.log('Error sending the file:', err);
            }
            fs.unlink(inputPath);
            fs.unlink(outputPath);
        });
    } catch (err) {
        console.log(`Error converting file: ${err}`);
        res.status(500).send('Error converting file.');
    }
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
{
    console.log(`Server is running on port ${PORT}`);
});
